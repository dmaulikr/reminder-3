//
//  VaFeedbackViewController.h
//  VaTouch
//
//  Created by Liangjun Jiang on 11/15/12.
//  Copyright (c) 2012 vAuto LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VaFeedbackViewController : UITableViewController

@end
